//--------------------------------------------------------
// 	Assignment #1
// 	Written by: Darian Yee (40063058)
// 	For COMP-248-2172-S - Winter 2018
//------------------------------------------------------


//QUESTION #3
//Darian Yee, January 28th, 2018
//Program asks the user to fill out 4 questions on a scale out of ten
//Based on their answers the program will determine the user's personality

//Using a scanner to get user input
import java.util.Scanner ;

public class Question3 {

	public static void main(String[] args) {
		
		//Display a welcome message and asks the user if they want to take a personality test
		
		System.out.println("---------------------------------");
		System.out.println("The Simple Personality Test!");
		System.out.println("---------------------------------");
		
		System.out.println("Are you ready for a personality test? (Yes/No): ") ;
		Scanner keyIn = new Scanner (System.in) ;
		
		String yn = keyIn.next(); 
		
		if (yn.equalsIgnoreCase("Yes"))
			 System.out.println("All right here we go!");
		else 
			 System.out.println("Alright, well we're going to do it anyways!\n");
		 
		 //Program asks the user to answer the following questions on a scale from 1-10
		 //Stores user input as a variable
		 
		 System.out.println("Answer the following questions on a scale from 1-10.") ;
		 System.out.println("Q1 : How do you get your energy?") ;
		 System.out.println("1 - - By spending time alone");
		 System.out.println("10 - - By spending time with others");
		 
		 int n1 = keyIn.nextInt();
		 
		 System.out.println("Q2 : How do you see the world & gather information?") ;
		 System.out.println("1 - - In concrete terms");
		 System.out.println("10 - - In abstract terms");
		 
		 int n2 = keyIn.nextInt();
		 
		 System.out.println("Q3 : How do you make your decisions?");
		 System.out.println("1 - - Using my head");
		 System.out.println("10 - - Using my heart");
		 
		 int n3 = keyIn.nextInt();
		 
		 System.out.println("Q4: How much do you like to plan?");
		 System.out.println("1 - - Make plans far in advance");
		 System.out.println("10 - - Go with the flow");
		 
		 int n4 = keyIn.nextInt(); 
		 
		 System.out.print("Your personality type is: *" );
		 
		 if(n1 <= 5)
			 System.out.print("I");		//Displays "I" for Introvert if user submits a number <= 5
		 else 
			 System.out.print("E");		//Displays "E" for Extrovert if user submits a number > 5
		 
		 if (n2 <= 5)
			 System.out.print("S");		//Displays "S" for Sensors if user submits a number <= 5
		 else
			 System.out.print("N");		//Displays "N" for iNtuitives if user submits a number > 5
		 
		 if (n3 <= 5)
			 System.out.print("T");		//Displays "T" for Thinkers if user submits a number <= 5
		 else
			 System.out.print("F");		//Displays "F" for Feelers if user submits a number > 5
		 
		 if (n4 <= 5)
			 System.out.print("J*\n");	//Displays "J" for Judgers if user submits a number <= 5
		 else
			 System.out.print("P*\n"); 	//Displays "P" for Perceivers if user submits a number > 5
		 
		 //Displays closing message and a web site where user can find out more information about their personality type.
		 System.out.println("To find out more about that type of personality check out:");
		 System.out.println("https://www.truity.com/view/types");
		 System.out.println("Hope you had fun! See you next time!");
		
		 //closes scanner
		 keyIn.close() ;
		
	
	
	}
	
}
