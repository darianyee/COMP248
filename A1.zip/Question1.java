//--------------------------------------------------------

// 	Assignment #1
// 	Written by: Darian Yee (40063058)
// 	For COMP-248-2172-S - Winter 2018
//------------------------------------------------------


//QUESTION #1
//Darian Yee, January 28th, 2018
//Program asks the user to fill out their student information (name, program, year, id, login name and GPA) 

//Using a scanner to get user input
import java.util.Scanner;

public class Question1 
{	
	public static void main(String[] args)
	
	{	Scanner keyIn = new Scanner (System.in) ;
	
		//Displaying a welcome message
	
		System.out.println("Welcome! Please fill in the following \n") ;
	
		System.out.println("----------------------------------------");
		System.out.println("Student Information System");
		System.out.println("----------------------------------------");
		
		// Prompting user for input and information, then storing it as a variable
		
		System.out.println("What is your first name? ") ;
		String fname = keyIn.next () ;			
		
		System.out.println("What is your last name? ");			
		String lname = keyIn.next () ;	
		
		System.out.println("What is you major? ");			
		String major = keyIn.next() ;	
		
		System.out.println("What year are you in? ");
		int year = keyIn.nextInt () ;			
		
		System.out.println("What is your student ID?") ;
		int id = keyIn.nextInt () ;				
		
		System.out.println("What is your login name? ");
		String login = keyIn.next () ;			
		
		System.out.println("What is your GPA (0.0 to 4.3)? ");
		double gpa = keyIn.nextDouble () ;			
		
		//Display a summary of the user's student information by using the information stored from variables
		//Display results
		System.out.println("Your student information: ");
		System.out.println ("	Login: " + login) ;
		System.out.println ("	ID: " + id) ;
		System.out.println ("	Name: " + lname + ", " + fname) ; 
		System.out.println ("	Field and year: " + major + ", " + year) ;
		System.out.println ("	GPA: " + gpa) ;
		
		//Display a closing message
		System.out.println ("That's all folks!") ;
		
		//closes scanner keyIn
		keyIn.close () ;
		
		
		
	}

}
