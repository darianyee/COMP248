//--------------------------------------------------------
// 	Assignment #1
// 	Written by: Darian Yee (40063058)
// 	For COMP-248-2172-S - Winter 2018
//------------------------------------------------------

//QUESTION #2
//Darian Yee, January 28th, 2018
//Program asks the user for their name and age.
//Depending on their age, the program  displays a message saying what they can't do (if age < 25)
//or let's them know that they can do anything that is legal (if age > 25).

/****************************************************************/
/******** All the things you cannot do... **************/
/****************************************************************/

//Using a scanner to get user input

import java.util.Scanner ; 

public class Question2 {

	public static void main(String[] args) {
		
		Scanner keyIn = new Scanner (System.in) ;
		
		//Display a welcome message and ask user for their name and age
		
		System.out.println("Welcome!");
		
		System.out.println("Hi there, what's your name?");
		String name = keyIn.next() ;
		
		System.out.println("Nice to meet you " + name + ", how old are you?");
		int age = keyIn.nextInt() ;
		
		System.out.print("Ok, " + name + " did you know, ");
		
		//Program displays different messages depending on the user's age
		
		if (age < 16) 
			System.out.println("you can't drive.\n");
		
		else if (age <18)
			System.out.println("you can't vote.\n");
		
		else if (age < 25)
			System.out.println("you can't rent a car.\n");
		
		else 
			System.out.println("you can do anything that's legal.\n") ;
		
		//displays a closing message
		System.out.println("Have a great day!");
		
		//closes scanner "keyIn"
		keyIn.close();
		
	}

}
