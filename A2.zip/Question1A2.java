//--------------------------------------------------------
// 	Assignment #2
// 	Written by: Darian Yee (40063058)
// 	For COMP-248-2172-S - Winter 2018
//------------------------------------------------------

//QUESTION #1
//Darian Yee, March 1st 2018

// Program asks the officer a series of questions to determine what the fine should be, the amount of demerit 
// points the driver has and if they lose their driver's license

// Import Scanner to get user input
import java.util.Scanner ;
public class Question1A2 {

	public static void main(String[] args) {
		
		Scanner keyIn = new Scanner (System.in);
		
		//Welcome message
		System.out.println("---------------------------------------------------");
		System.out.println(" Welcome to the Fine and Demerit Point Evaulator!");
		System.out.println("---------------------------------------------------") ;
		
		//Asking the officer where the driver was stopped
		System.out.println("Welcome Officer - I need some information before I tell you what the fine and demerit points are.");
		System.out.println("Here are the possible locations");
		System.out.println("1 - Driver was stopped on the highway");
		System.out.println("2 - In a school zone");
		System.out.println("3 - Car is stopped at a Stop sign or traffic light");
		System.out.println("4 - None of the above");
		
		System.out.println("Please enter the digit corresponding to your case: ");
		
		//Initializing variable that determines the location
		int locType = keyIn.nextInt() ;
		
		// Using a switch statement and nested if statements to determine the fine and demerit points the driver has
		// If the driver has 12 or more demerit points, s/he loses their license
		
		//Evaluating where the driver was stopped
		switch (locType)
		{
			//If the driver was stopped on the highway
			case 1:
			{
				//Asking the driver if its their first offense to determine the fine and how many demerit points are added
				System.out.println("Officer, is this the driver's 1st offence (answer with y for yes and anything else for no)? ") ;
				String yn = keyIn.next(); 
		
				System.out.println("How many demerit points did the driver have prior to being stopped?");
				//Initializing variables
				int demerit1 = keyIn.nextInt();
				int nDemerit1 ;
		
					//If its the driver's first offense they get a ticket for $80 and add 1 demerit point
					//If they now have 12 demerit points, they lose their driver's license
					if (yn.equalsIgnoreCase("y"))
					{
						nDemerit1 = demerit1 + 1;
						System.out.println("Officer write a ticket for $80, and inform the driver that they now have "
								+ nDemerit1 + " points");
						if (nDemerit1 >= 12)
							System.out.println("Please take away their driver's license and make arrangments to have the car towed" +
									" right away.") ;
					}	
					
					//If its not the driver's first offense, they get a ticket for $80 and add 2 demerit points
					//If the driver now has 12 or more demerit points, they lose their driver's license
					else
					{	
						nDemerit1 = demerit1 + 2 ;
						System.out.println("Officer write a ticket for $80, and inform the driver that they now have " 
								+ nDemerit1 + " points");
						if (nDemerit1 >= 12)
							System.out.println("Please take away their driver's license and make arrangments to have the car towed" +
									" right away.") ;
					}
					
						break;
			}
			
			//If the driver was stopped in a school zone
			case 2: 
			{
				//Asking the driver how many months they've had their license to determine how many demerit points they now have, and
				// if they lose their driver's license
				System.out.println("How many months has the driver had their liscence?") ;
				int month = keyIn.nextInt();
			
					//If the driver had their driver's license for less than 24 months, they get a fine for $100 and lose their license
					if (month < 24)
						System.out.println("Officer, write a ticket for $100, take away their driver's license on "
								+ "the spot and make arrangements to have the car towed away.");
					
					//If the driver had their license for 24 months or more, they get a fine for $100 and add 4 demerit points
					//If the driver now has 12 or more demerit points, they lose their license
					else
					{	
						System.out.println("How many demerit points did the driver have prior to being stopped?");
						int demerit2 = keyIn.nextInt();
						int nDemerit2 = demerit2 + 4;
						System.out.println("The fine is $100 and the driver now has " + nDemerit2 + " points");
						if (nDemerit2 >= 12)
							System.out.println("Please take away their driver's license and make arrangments to have the car towed" +
									" right away.") ;
					}
		
				break;
			}
		
			//If the driver was stopped at a Stop sign or traffic light
			case 3: 
			{
				//Asking the driver if they were on an Iphone to determine how many demerit points to add
				System.out.println("Officer, is the cellphone in question an Iphone (answer with y for yes "
						+ "and anything else for no);?");
				
				//Initializing variables
				String y_n = keyIn.next() ;
				System.out.println("How many demerit points did the driver have prior to being stopped?");
				int demerit3 = keyIn.nextInt();
				int nDemerit3 ;
		
					//If it was an Iphone, write a ticket for $100 and add 2 demerit points
					//If the driver now has 12 or more demerit points, they lose their license
					if (y_n.equalsIgnoreCase("y"))
					{
						nDemerit3 = demerit3 + 2 ;
						System.out.println("Write a ticket for $100 and inform the driver that they now have " + nDemerit3 + 
								" demerit points.");
						if (nDemerit3 >= 12)
							System.out.println("Please take away their driver's license and make arrangments to have the car towed" +
									" right away.") ;
					}	
					
					//If it was not an Iphone, write a ticket for $80 and add 1 demerit point
					//If the driver now has 12 demerit points, they lose their license
					else
					{	
						nDemerit3 = demerit3 + 1;
						System.out.println("Write a ticket for $80 and infrom the driver that they now have " + nDemerit3 + 
								" demerit points.");
						if (nDemerit3 >= 12)
							System.out.println("Please take away their driver's license and make arrangments to have the car towed" +
									" right away.") ;
					}
				
					break;
			}	
		
			//If the driver was not stopped at any of the other options, write a fine for $90 and add 3 demerit points
			//If they now have 12 or more demerit points, they lose their license
			default:  
			{
				System.out.println("How many demerit points did the driver have prior to being stopped?");
				int demerit4 = keyIn.nextInt();
				int nDemerit4 = demerit4 + 3;
				System.out.println("The fine is $90 and the driver now has " + nDemerit4 + " points.");
				
				if (nDemerit4 >= 12)
					System.out.println("Please take away their driver's license and make arrangments to have the car towed" +
							" right away.") ;
			}
		}	
	
		//Displaying a closing message
		System.out.println("\nGood job officer! Keep up the good work!");
		
	//closing Scanner
	keyIn.close();

	}

}
