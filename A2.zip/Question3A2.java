//--------------------------------------------------------
// 	Assignment #2
// 	Written by: Darian Yee (40063058)
// 	For COMP-248-2172-S - Winter 2018
//------------------------------------------------------


//QUESTION #3
//Darian Yee, March 1st 2018

// Program displays a triangle of numbers
// The size (a number from 5-10) determines the number of rows and the seed (a number from 1-9) determines which number the triangle starts with

// Import Scanner to get user input
import java.util.Scanner;
public class Question3A2 {

	public static void main(String[] args) {
		
		Scanner keyIn = new Scanner (System.in);
		
		//Initializing variables
		int seed;				
		int size;
		int r; 
		int num;
		int count = 0;
		boolean valid=true;
		
		//Displaying a welcome message
		System.out.println("---------------------------------------------------");
		System.out.println("Welcome to Nancy's Parkside's Triangle Producer");
		System.out.println("---------------------------------------------------");
		
		
	//Using a do while loop to 	ensure that the user inputs a number from 5-10 as their size
	do
	{
		System.out.println("Please enter a size (must be between 5 and 10 inclusive): ") ;
		size = keyIn.nextInt();
		valid = (size >= 5 && size <= 10 );
	}
	while (!valid);
	
	//Using a do while loop to ensure that the user inputs a number from 1-9 as their seed
	do
	{	
		System.out.println("Please enter a seed (must be between 1 and 9 inclusive): ") ;
		seed = keyIn.nextInt();
		valid = (seed >= 1 && seed <= 9);
		if (!valid)
			System.out.print("");
	}	
	while (!valid);
	
	//First for loop is used to display the amount of rows the user selected
	for (r = 1; r <= size ; r++)
	{
		//Second for loop is used to input the amount of numbers in each row
		for (num = 1; num <= 1 + count ; num++)
		{
			System.out.print(seed + " ");
			//resets the seed back to 0 if its equal to 9 
			if (seed == 9)
				seed=0;
			//increments the seed by 1 so that the next number is increased by 1
			seed++;
		}
		
		//increments the count by 1
		//count is used to increase the amount of numbers outputted in each row
		count++;
		System.out.println();
	}
	
	//Displays a closing message
	System.out.println("\nAll done!");
	
	//Closes the Scanner
	keyIn.close();
	}
		
}

