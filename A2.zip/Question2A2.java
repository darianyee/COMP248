//--------------------------------------------------------
// 	Assignment #2
// 	Written by: Darian Yee (40063058)
// 	For COMP-248-2172-S - Winter 2018
//------------------------------------------------------


//QUESTION #2
//Darian Yee, March 1st 2018

// Program asks the user to input two numbers (at most three digits each) and demonstrates how to find its sum
// The program continues until the user inputs anything other than 'y' to stop

// Import Scanner to get user input

import java.util.Scanner;
public class Question2A2 {

	public static void main(String[] args) {
		
		Scanner keyIn = new Scanner (System.in) ;
	
			//Initializing variable
		
			String i = "y";
			
			//Displaying a welcome message
			System.out.println("Welcome to the Addition Tutorial Program!\n");
			
			//Using a do while loop to find the sum of two numbers obtained from the user until they wish to stop
			do
		
			{
				//Asking the user to input two numbers and storing them as num1 and num2
				System.out.println("Enter two numbers with at most 3-digits each, seperated by a space and press enter: ");
				int num1 = keyIn.nextInt() ;
				int num2 = keyIn.nextInt() ;
				
				System.out.println("You have requested the following operation:\n");
				System.out.println("num1:   " + num1);
				System.out.println("num2: + " + num2);
				System.out.println("       --------\n");
		
				//Demonstrating how to add the last digits of the two numbers
				System.out.println("1st addition:");
				System.out.println("last digit of each number");
			
				// Adding the last digit of the two numbers and carrying the first digit of the sum if the sum is greater than 9
				int fn1 = ( ((num1 % 100) % 10));
				int fn2 = ( ((num2 % 100) % 10 ) ) ;
				int sum1 = fn1 + fn2;
				int carry1 = sum1/10 ;
				
				//Displaying the last digit of each number and showing the sum
				System.out.println(fn1 + " + " + fn2 + " = " + sum1 + " so the answer is " + sum1 + " with a "
						+ "carry of " + carry1 + "\n") ;
			
				System.out.println("2nd addition:");
				System.out.println("the carry from the previous addition plus the middle digit of each number");
				
				//Demonstrating how to add the second to last digit of each number and finding its sum
				//Carry the first digit of the sum if the sum is greater than 9
				int sn1 = ( ((num1 % 100) / 10));
				int sn2 = ( ((num2 % 100) / 10 ) ) ;
				int sum2 = sn1 + sn2 + carry1;
				int carry2 = sum2/10 ;
				
				// Displaying the second to last digit of each number and showing the sum
				System.out.println(carry1 + " + " + sn1 + " + " + sn2 + " = " + sum2 + " so the answer is " + sum2 + " with "
						+ "a carry of " + carry2 +"\n");
			
				System.out.println("3rd addition:");
				System.out.println("the carry from the previous addition plus the first digit of each number");
		
				//Demonstrating how to add the third to last digit of each number and showing the sum
				int tn1 = (num1 / 100);
				int tn2 = (num2 / 100) ;
				int sum3 = tn1 + tn2 + carry2;
				int ans = num1 + num2 ;
				
				//Displaying the third to last digit of each number and showing the sum
				System.out.println(carry2 + " + " + tn1 + " + " + tn2 + " = " + sum3 + " so the answer is " + sum3 + "\n");
				
				//Displaying the sum of the two numbers the user input
				System.out.println("Final answer: ");
				System.out.println("num1:     " + num1);
				System.out.println("num2:   + " + num2);
				System.out.println("       --------");
				System.out.println("	 " + ans);
	
				//Asking the user if s/he wants to try another addition
				System.out.println("Do you want to try another one? (y or Y to repeat)");
				i = keyIn.next();
			
			}	
			
			//Program runs until the user inputs anything other than 'y' or 'Y'
			while (i.equalsIgnoreCase("y"));
			
			//Displaying a closing message
			System.out.println("Hope you are more comfortable with additions now! If not, don't hesitate to come back");
			
			//Closing Scanner
			keyIn.close();
	}
	
	
	
}
