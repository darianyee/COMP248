//--------------------------------------------------------
// 	Assignment #3
// 	Written by: Darian Yee (40063058)
// 	For COMP-248-2172-S - Winter 2018
//------------------------------------------------------

//QUESTION #2
//Darian Yee, March 17st 2018

// Program asks the user which type of square they would like to create until they decide to quit
// Depending on the square the user selects, the program asks the user for the size of the square, 
// which characters to use, or a start number

//importing Scanner
import java.util.Scanner;
public class Assignment3Q2 {

	public static void main(String[] args) {
		
		Scanner keyIn = new Scanner (System.in);
		
		//initializing variables
		boolean valid=true;
		int type;
		int size = 0, num;
		char character, character1, character2;
		
		//Displaying a welcome message
		System.out.println("|-------****-------****-------****-------****-------****--------|");
		System.out.println("|\tWelcome to the Decorated Square Drawing Program!\t|");
		System.out.println("|-------****-------****-------****-------****-------****--------|\n");
		
		do 
		{	
			//Prompting the user which type of square they want
			System.out.println("What type of square would you like?");
			System.out.println("\t1 - Full Square");
			System.out.println("\t2 - Hollow square");
			System.out.println("\t3 - An X");
			System.out.println("\t4 - Horizontal Bars");
			System.out.println("\t5 - Vertical Bars");
			System.out.println("\t6 - Diagonal Bars");
			System.out.println("\t7 - Integer Filled Square");
			System.out.println("\t8 - Checkered (must be a multiple of 4)");
			System.out.println("\t9 - Quit");
	
			//Using a do while loop to make sure the user picks from one of the choices (1-9)
			do
			{
				System.out.println("Enter your choice (1-9): ");
				type = keyIn.nextInt();
				valid = (type<10 && type>0);
				if(!valid)
					System.out.println("Sorry! That is an illegal choice.");
			}
			while (!valid);
	
			//Using a do while to make sure the user selects the rows/columns to be a number from 4-20
			do
			{
				//If the user selects square 8, do while makes sure that the user selects a value that is a multiple of 4
				if (type==8)
				{
					System.out.print("How many rows and columns (min 4 & max 20, also needs to be a multiple of 4)? ");
					size = keyIn.nextInt();
					valid = (size%4==0 && size>=4 && size<=20);
				}
				
				//Verifying that user selects a number of rows that is from 4-20 if the user selected a square from 1-7
				if(type!=9&& type!=8)
				{
					System.out.print("How many rows and columns (min 4 & max 20)? ");
					size = keyIn.nextInt();
					valid = (size>=4 && size<=20);
				}
				
				if(!valid)
					System.out.println("Sorry! That is an illegal choice.");
			}
			while (!valid);
	
	
			//Using a switch statement to ask the user for appropriate input depending on the square they selected
			switch (type)
			{ 
				case 1:
				{
					//Asking the user for input
					System.out.print("Which character do you want to fill your square with? ");
					character = keyIn.next().charAt(0);
			
					//Displaying pattern
					System.out.println("\nHere is your pattern\n");
					//Calling method Square1
					Square1 (size, character);
					break;
		
				}

				case 2: 
				{
					//Asking the user for input
					System.out.print("Which character do you want for the border? ");
					character = keyIn.next().charAt(0);
			
					//Displaying pattern
					System.out.println("\nHere is your pattern\n");
					//Calling method Square2
					Square2 (size, character);
					break;
				}
			
				case 3: 
				{
					//Asking the user for input
					System.out.print("Which character do you want for the X? ");
					character1 = keyIn.next().charAt(0);
					System.out.print("Which character do you want around the X? ");
					character2 = keyIn.next().charAt(0);
			
					//Displaying pattern
					System.out.println("\nHere is your pattern\n");
					//Calling method Square3
					Square3 (size, character1, character2);
					break;
				}
			
				case 4: 
				{
					//Asking the user for input
					System.out.print("Which character do you want for even rows? ");
					character1 = keyIn.next().charAt(0);
					System.out.print("Which character do you want for the odd rows? ");
					character2 = keyIn.next().charAt(0);
			
					//Displaying pattern
					System.out.println("\nHere is your pattern\n");
					//Calling method Square4
					Square4 (size, character1, character2);
					break;
				}
		
				case 5: 
				{
					//Asking the user for input
					System.out.print("Which character do you want for even columns? ");
					character1 = keyIn.next().charAt(0);
					System.out.print("Which character do you want for the odd columns? ");
					character2 = keyIn.next().charAt(0);
			
					//Displaying pattern
					System.out.println("\nHere is your pattern\n");
					//Calling method Square5
					Square5 (size, character1, character2);
					break;
				}
		
				case 6: 
				{
					//Asking the user for input
					System.out.print("Which character do you want for even diagonals? ");
					character1 = keyIn.next().charAt(0);
					System.out.print("Which character do you want for the odd diagonals? ");
					character2 = keyIn.next().charAt(0);
			
					//Displaying pattern
					System.out.println("\nHere is your pattern\n");
					//Calling method Square6
					Square6 (size, character1, character2);
					break;
				}
		
				case 7: 
				{
			
					//Asking the user for input and making sure that the number is from 0-50 by using a do while loop
					do
					{
						System.out.print("What is the starting number for your integer filled square (between 0 and 50 inclusive) : ");
						num = keyIn.nextInt();
						valid = (num<=50 && num >= 0);
						
						if(!valid)
							System.out.println("Sorry! That is an illegal choice.");
					}
					while (!valid);
			
					//Displaying pattern
					System.out.println("\nHere is your pattern\n");
					//Calling method Square7
					Square7 (size, num);
					break;
				}
		
				case 8: 
				{
					//Asking the user for input
					System.out.print("Which character do you want for the 1st checker?");
					character1 = keyIn.next().charAt(0);
					System.out.print("Which character do you want for the 2nd checker?");
					character2 = keyIn.next().charAt(0);
			
					//Displaying pattern
					System.out.println("\nHere is your pattern\n");
					//Calling method Square8
					Square8 (size, character1, character2);
					break;
				}
		
			}
	
		}while(type!=9);

		//Displaying output message if the user selected option 9
		if (type ==9)
			System.out.print("\nHope you enjoyed your patterns!! Come back soon ...");
		
		//Closing Scanner
		keyIn.close();
		
}
	

	//Creating different methods	
	public static void Square1 (int size , char character) {
	
	//initializing array
	char [][] a = new char[size][size];
	
	//two for loops are used to fill up the 2D array
	for (int i = 0 ; i < a.length ; i++) 
		for (int j = 0 ; j < a.length ; j++) 
			a[i][j] = character;
	
	//Displaying the square by calling method
	PrintSquare(a);
	
	}

	public static void Square2 (int size , char character) {
	
		//initializing array
		char[][] a = new char [size][size];
	
		//Using two for loops to store the character the user selected into the 2D array
		//Only the array coordinates that are responsible for storing the character along boarder (first and last row and column),
		//store the character the user selected
		for (int i=0; i<a.length;i++)
		{
			for(int j=0; j<a.length;j++)
			{
				if(i==0||i==a.length-1||j==0||j==a.length-1)
					a[i][j]=character;
				else
					a[i][j]=' ';
			}
		}
		//Displaying the square by calling method
		PrintSquare(a);
	}

	public static void Square3 (int size , char character1, char character2) {
		
		//initializing array
		char[][] a = new char [size][size];
		
		//Using two for loops to store the character the user selected into the 2D array
		//The array coordinates that are responsible for storing the diagonals contain the first character the user input
		//Everything else is filled with the second character the user selected
		for (int i=0; i<a.length;i++)
		{
			for(int j=0; j<a.length;j++)
				{
					if (i==j)
					a[i][j]=character1;
					
					else if(i==(a.length-j-1))
						a[i][j]=character1;
				
					else
						a[i][j]=character2;
				}
		
		}
		//Displaying the square by calling method
		PrintSquare(a);
	
	}
	public static void Square4 (int size , char character1, char character2) {
		
		//initializing array
		char[][] a = new char [size][size];
		
		//Using two for loops to store the character the user selected into the 2D array
		//The array coordinates that are responsible for storing the even rows contain the first character the user input
		//Everything else is filled with the second character the user selected
		for (int i=0; i<a.length;i++)
		{
			for(int j=0; j<a.length;j++)
			{
				if(i%2==1)
					a[i][j]=character1;
				else
					a[i][j]=character2;
			}
		}
		//Displaying the square by calling method
		PrintSquare(a);
	}
	
	public static void Square5 (int size , char character1, char character2) {
		
		//initializing array
		char[][] a = new char [size][size];
		
		//Using two for loops to store the character the user selected into the 2D array
		//The array coordinates that are responsible for storing the even columns contain the first character the user input
		//Everything else is filled with the second character the user selected
		for (int i=0; i<a.length;i++)
		{
			for(int j=0; j<a.length;j++)
			{
				if(j%2==1)
					a[i][j]=character1;
				else
					a[i][j]=character2;
			}
		}
		//Displaying the square by calling method
		PrintSquare(a);
	}
	
	public static void Square6 (int size , char character1, char character2) {
	
		//initializing array
		char[][] a = new char [size][size];
		
		//Using two for loops to store the character the user selected into the 2D array
		//The array coordinates that are responsible for storing the even diagonals contain the first character the user input
		//Everything else is filled with the second character the user selected
		for (int i=0; i<a.length;i++)
		{
			for(int j=0; j<a.length;j++)
			{
				if((i+j)%2==0)
					a[i][j]=character1;
				else
					a[i][j]=character2;
			}
		}
		//Displaying the square by calling method
		PrintSquare(a);
		}

	public static void Square7 (int size , int snum) {
	
		//initializing array
		int[][] a = new int [size][size];
		int lnum = snum + size*size - 1 ;
	
		//Using two for loops to store the character the user selected into the 2D array
		//the values where j(column) is greater than or equal to i(row), 
		//the start number the user selected is stored into the according array coordinate and then incremented by 1
		//the values where j (column) is less than i (row), 
		//the end number is stored into the according array coordinate and then decremented by one
		
		for (int i=0; i<a.length;i++)
		{
			for(int j=0; j<a.length;j++)
			{
				if(j>=i)
					a[j][i]=snum++;
				else
					a[j][i]=lnum--;
			}
		}	

		//Using two arrays to display the square
		for (int i=0; i<a.length;i++)
		{
			for(int j=0; j<a.length;j++)
				System.out.print(a[i][j] + " ");
			System.out.println();
		}
		System.out.println();
	}

	public static void Square8 (int size , char character1, char character2) {
	
		//initializing array
		char[][] a = new char [size][size];
		
		//Using two for loops to store the character the user selected into the 2D array
		//The array coordinates that are responsible for storing the even (2x2 box) diagonals contain the second character the user input
		//Everything else is filled with the first character the user selected
		for (int i=0; i<a.length;i++)
		{
			for(int j=0; j<a.length;j++)
			{
				if((i/2+j/2)%2==1)
					a[i][j]=character1;
				else
					a[i][j]=character2;
			}
		}
		//Displaying the square by calling method
		PrintSquare(a);
	}


	public static void PrintSquare (char[][] a ) {
	
		//Using two for loops to print out the square
		for (int i=0; i<a.length;i++)
		{
			for(int j=0; j<a.length;j++)
				System.out.print(a[i][j] + " ");
			System.out.println();
		}
		System.out.println();
	}
}


