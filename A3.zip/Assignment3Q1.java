//--------------------------------------------------------
// 	Assignment #3
// 	Written by: Darian Yee (40063058)
// 	For COMP-248-2172-S - Winter 2018
//------------------------------------------------------

//QUESTION #1
//Darian Yee, March 17st 2018

// Program simulates the tossing of darts to different regions on a dart board. 
// Once the total points is equal to or exceeds 1000, the number of hits and points for each region are displayed
// Program displays the number of hits it took you to reach 1000 points

// Import Random number generator to get a random toss to a region

import java.util.Random;
public class Assignment3Q1 {

	public static void main(String[] args) {
		
	//Displaying a welcome message	
	System.out.println("|----------------->>>><<<<-----------------|");	
	System.out.println("|Welcome to the Simplified Dart Game!\t   |");
	System.out.println("|----------------->>>><<<<-----------------|\n");
	
	//Displaying the darts score table for the region hit, the number of hits and points for the particular region 
	System.out.println("Region\tHits\tPoints");
	System.out.print("------------------------------------------");
		
	//initializing variables
	int totalpoints, region = 0;
	
	//need an array to hold ten variables because there are ten different regions
	int [] hits = new int[10]; 		
	int [] points = new int [10];
	
	Random dart = new Random();
	int count=0;

	//Use a for loop to simulate the random tossing of darts to different regions until the total points are equal to or greater than 1000
	for (totalpoints=0;totalpoints<1000;)
	{
		//dart is tossed to a region (1-10)
		region = 1+dart.nextInt(10);
		
		//the hit count for that particular region is increased by one
		hits[region-1]++;
		int i= (region-1);
		
		//Use a switch statement to calculate the total points for each region
		//Also adds the appropriate amount of points to the total points 
		switch (i)
		{
			case 0:
			{
				points[0]= (hits[0])*7;
				totalpoints+=7;
				break;
			}
			case 1:
			{
				points[1]= (hits[1])*5;
				totalpoints+=5;
				break;
			}
			case 2:
			{
				points[2]= (hits[2])*5;
				totalpoints+=5;
				break;
			}
			case 3:
			{
				points[3]= (hits[3])*5;
				totalpoints+=5;
				break;
			}
			case 4:
			{
				points[4]= (hits[4])*3;
				totalpoints+=3;
				break;
			}
			case 5:
			{
				points[5]= (hits[5])*3;
				totalpoints+=3;
				break;
			}
			case 6:
			{
				points[6]= (hits[6])*3;
				totalpoints+=3;
				break;
			}
			case 7:
			{
				points[7]= (hits[7])*1;
				totalpoints+=1;
				break;
			}
			case 8:
			{
				points[8]= (hits[8])*1;
				totalpoints+=1;
				break;
			}
			case 9:
			{
				points[9]= (hits[9])*1;
				totalpoints+=1;
				break;
			}
			
		}

		//increasing the count of total number of darts thrown
		count++;
	}
		
	System.out.println();
	
	//Using a for loop to display the number of hits and points for each respective region
	for (int j=0; j<10; j++)
		System.out.println(" " + (j+1) + "\t" + hits[j] + "\t" + points[j]);
	
	//Displaying the total amount of darts thrown to reach a total of at least 1000 points
	System.out.println("\nIt took " + count + " tosses for a total of " + totalpoints);
	
	//Displaying a closing message
	System.out.println("\nThat was an effortless game of darts!");


	}
				
}

