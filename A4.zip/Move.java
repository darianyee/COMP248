//move class
public class Move {

	//two attributes colour and number
	private char colour;
	private int number;
	
	//get method for colour
	public char getColour() {
		return colour;
	}
	
	//get methtod for number
	public int getNumber () {
		return number;
	}
			
	//set method for colour
	public void setColour(char c1 ) {
		colour = c1;
	}
	
	//set method for number
	public void setNumber (int num) {
		number = num;
	}
	
	//set method for dice
	public void setDice (char colour1, int num1) {
		colour = colour1;
		number = num1;
	}
	
	//converts the character of each colour to a number
	public static int convertColourtoNum(char c1) {
		switch (c1)
		{
			case 'R':
				return 0;
			case 'Y':
				return 1;
			case 'G':
				return 2;
			case 'B':
				return 3;
			default:
				return c1;
		}
	}
	
}
