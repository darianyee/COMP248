//importing Scanner
import java.util.Scanner;

//Qwixx class
public class Qwixx {
	
	//initializing scanner
	Scanner keyIn = new Scanner(System.in);
	
	//declaring attributes
	private Dice[] die = new Dice[6];
	private Player[] people;
	private boolean lockred, lockyellow, lockgreen, lockblue;
	private static final int NEGPTS = -5;
	
	public void Qwixx() {
		//player stuff
		//declaring variables
		Scanner keyIn = new Scanner (System.in);
		int nbplayers;
		boolean valid;
		String pname1, pname2, pname3, pname4, pname5;
		
		//using a do while loop to verify that the user inputs a number from 2-5 for the number of players
		do 
		{	
			System.out.println("Please enter the number of players (2-5): ");
			nbplayers = keyIn.nextInt();
			valid = (nbplayers >= 2 && nbplayers <=5 );
			if (!valid)
				System.out.println("You must have between 2 and 5 players");
		}
		while (!valid);
		
		//creating an array of players with the number of players the user input
		people = new Player[nbplayers];
		
		//using a for loop to create the specified amount of players the user chose
		for (int i=0; i<nbplayers; i++) {
			people[i] = new Player(); 
		}
	
		//Creating objects of type dice
		//creating the 6 die 
		Dice red = new Dice("red");
		die[0] = red;
		Dice yellow = new Dice("yellow");
		die[1] = yellow;
		Dice green = new Dice("green");
		die[2] = green;
		Dice blue = new Dice("blue");
		die[3] = blue;
		Dice white1 = new Dice();
		die[4] = white1;
		Dice white2 = new Dice();
		die[5] = white2;
	}
	
	//roll method for red dice
	public int rollred() {
		return die[0].rollDice();
	}
	
	//roll method for yellow dice
	public int rollyellow() {
		return die[1].rollDice();
	}
	
	//roll method for green dice
	public int rollgreen() {
		return die[2].rollDice();
	}
	
	//roll method for blue dice
	public int rollblue() {
		return die[3].rollDice();
	}
	
	//roll method for white1 dice
	public int rollwhite1() {
		return die[4].rollDice();
	}
	
	//roll method for white2 dice
	public int rollwhite2() {
		return die[5].rollDice();
	}
	
	//get method for the sum of the two white dice
	public int getWhiteDiceTotal() {
		return die[4].getcurrentSide() + die[5].getcurrentSide();
	}
	
	//method that returns the value rolled by each dice
	public String printRolledDice() {
		return "Red dice: " + die[0].getcurrentSide() + " | Yellow dice: " + die[1].getcurrentSide() + " | Green dice: " 
				+ die[2].getcurrentSide() + " | Blue dice: " + die[3].getcurrentSide() + " | White1 dice: " 
				+ die[4].getcurrentSide() + " | White2 dice: " + die[5].getcurrentSide();
	}
	
	//Asks the player if they would like to use the sum of the white dice
	public String playWhiteDiceMove() {
		return "The total for the two white dice is " + die[4].getcurrentSide() + die[5].getcurrentSide()
				+ "\nWould you like to cross off a number on the game board using the white dice total? (anything other than 'yes'" +
				" is taken to mean no)";
	}
	
	//initialize game board to true 
	public void initializeBoard() {
		boolean[] redBoard = new boolean[11]; 
		boolean[] yellowBoard = new boolean[11];
		boolean[] greenBoard = new boolean[11];
		boolean[] blueBoard = new boolean[11];
		
		int i;
		
		for (i = 0; i < redBoard.length; i++)
		{
			redBoard[i] = true;	
		}
		
		for (i = 0; i < yellowBoard.length; i++)
		{
			yellowBoard[i] = true;	
		}
		
		for (i = 0; i < greenBoard.length; i++)
		{
			greenBoard[i] = true;	
		}
		
		for (i = 0; i < blueBoard.length; i++)
		{
			blueBoard[i] = true;	
		}

	}
	
	//check valid move method if the move is invalid, the array will contain the value 'true'
	//if the move is invalid, it will return the value 'false'
	public static boolean checkValidMove(Player p, Move m) {
		int colourArray;
		colourArray = m.convertColourtoNum(m.getColour());
		
		if(colourArray==0) {
			p.getGameBoard(m);
			if(p.gameBoard[colourArray][m.getNumber()-2])>p.getLastRed())
				return true;
		}
		
		if(colourArray==1) {
			p.getGameBoard(m);
			if(p.gameBoard[colourArray][m.getNumber()-2])>p.getLastRed())
				return true;
		}
		
		if(colourArray==2) {
			p.getGameBoard(m);
			if(p.gameBoard[colourArray][12-m.getNumber()])>p.getLastRed())
				return true;
		}
		
		if(colourArray==3) {
			p.getGameBoard(m);
			if(p.gameBoard[colourArray][12-m.getNumber()])>p.getLastRed())
				return true;
		}
		
		else
			return false;
			
	}
	
}
