//--------------------------------------------------------
// 	Assignment #4
// 	Written by: Darian Yee (40063058)
// 	For COMP-248-2172-S - Winter 2018
//------------------------------------------------------

//QUESTION #1
//Darian Yee, April 16th, 2018

// Program simulates a board game with 6 different dice and a game board
// There are four rows of numbers, two go from 2-12 and the other two go from 12-2
// the objective of the game is to cross off as many numbers as possible, and the winner is the player with the most points

// Import Scanner
import java.util.Scanner;

//Driver 
public class Assignment4 {

	public static void main(String[] args) {
		
		//initializing Scanner
		Scanner keyIn = new Scanner (System.in);
		
		//declaring variables
		int nbplayers;
		boolean valid;
		String pname1, pname2, pname3, pname4, pname5;
		
		//Using a do while loop to verify that the user inputs a number from 2-5 for the number of players
		do 
		{	
			System.out.println("Please enter the number of players (2-5): ");
			nbplayers = keyIn.nextInt();
			valid = (nbplayers >= 2 && nbplayers <=5 );
			if (!valid)
				System.out.println("You must have between 2 and 5 players");
		}
		while (!valid);
		
		
	}
}
