//importing random generator
import java.util.Random;

//dice class
public class Dice {

	//initializing two attributes
	private String colour;
	private int currentside;
	
	//default constructor
	//if there is no input, the colour of dice is set to white
	//and the dice is rolled using the rollDice() method
	public Dice() {
		colour="white";
		currentside = rollDice();
	}
	
	
	//default constructor
	//if there is one input of type String, it sets the colour of the dice
	//sets the current side using the rollDice method
	public Dice (String c1) {
		colour = c1;
		currentside = rollDice();
	}
	
	//assigns the current side of the dice using the random generator (number from 1-6)
	public int rollDice() {
		Random side = new Random();
		currentside = 1+side.nextInt(6);
		return currentside;
	}
 	
	//get method for the colour of the dice
	public String getColourDice () {
		return colour;	
	}
	
	//get method for the current side of the dice
	public int getcurrentSide () {
		return currentside;
	}
	
	//set method for the colour of the dice
	public void setColourDice (String c1 ) {
		colour = c1;	
	}
			
	//to string method that returns the colour and current side of the dice
	public String toString() {
		
		return "The colour is " + colour + " and the current side of the dice is  " + currentside;
	}
	
	
}
