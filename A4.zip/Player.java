//importing Scanner
import java.util.Scanner;

//Player class
public class Player {

	//declaring attributes
	private String name;
	private String gameBoard[][] = new String [4][11] ;
	private int negativePoints;
	private int LastRed, LastGreen, LastBlue, LastYellow;

	//initializing Scanner
	Scanner keyIn = new Scanner (System.in);
	
		//default constructor
		public Player() {
			String n1 = getPlayername();
			name=n1;
			negativePoints = 0;
			gameBoard = initializeGameboard();
			LastRed = 0;
			LastGreen = 0;
			LastBlue = 0;
			LastYellow = 0; 
		}

		//creating the Game board
		public String[][] initializeGameboard() {
			return gameBoard = new String[][] {

					{ "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12" }, // red line
					{ "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12" }, // yellow line
					{ "12", "11", "10", "9", "8", "7", "6", "5", "4", "3", "2" }, // green line
					{ "12", "11", "10", "9", "8", "7", "6", "5", "4", "3", "2" } // blue line
			};

		}
		
		
		//get game board method
		public String[][] getGameBoard(Move m){
			return gameBoard;
		}
		
		//prints the game board by using a for loop for each colour
		public void printGameBoard() {
				
		System.out.print("Red: ");	
			for (int j=0; j<11;j++)
				System.out.print(gameBoard[0][j] + " ");
			System.out.println();
		
		System.out.print("Yellow: ");	
			for (int j=0; j<11;j++)
				System.out.print(gameBoard[1][j] + " ");
			System.out.println();	
			
		System.out.print("Green: ");	
			for (int j=0; j<11;j++)
				System.out.print(gameBoard[2][j] + " ");
			System.out.println();
			
		System.out.print("Blue: ");	
			for (int j=0; j<11;j++)
				System.out.print(gameBoard[3][j] + " ");
			System.out.println();
		}
		
		//set method for player's name
		public void setPlayername(String n1) {
			name=n1;
		}
		
		//get method for player's name
		public String getPlayername() {
			return name;
		}
		
		//set method for negative points
		public void setnegativePoints(int n1) {
			negativePoints = n1;
		}
		
		//get method for negative points
		public int getnegativePonts() {
			return negativePoints;
		}
		
		//method that adds the negative points
		public void addnegativepoints(int negpoints) {
			negativePoints = negativePoints + negpoints;
		}
		
		//make move method which replaces the value in the array with an X when the payer wants to make the move
		//Depending on the location of the array, it will store the the last value for the variable depending on the colour chosen
		public void makeMove(Move m) {
		
		int c = m.convertColourtoNum(m.getColour());
		
		if(c==0 || c==1)
			gameBoard[c][(m.getNumber())-2]= "X";
		else
			gameBoard[c][12-(m.getNumber())]= "X";
		if(c==0)
			LastRed= m.getNumber();
		if (c==1)
			LastYellow = m.getNumber();
		if(c==2)
			LastGreen = m.getNumber();
		if(c==3)
			LastBlue = m.getNumber();
		}
		
		//get method for the last value crossed off for red
		public int getLastRed() {
			return LastRed;
		}
		
		//get method for the last value crossed off for yellow
		public int getLastYellow() {
			return LastYellow;
		}
		
		//get method for the last value crossed off for green
		public int getLastGreen() {
			return LastGreen;
		}
		
		//get method for the last value crossed off for blue
		public int getLastBlue() {
			return LastBlue;
		}
		
		
		//get method for total points
		//uses a for loop to count the number of "X" for each colour
		//depending on the number of "X" a switch statement is used to accumulated the points
		public int getBoardTotalMethod() {
			int count1 = 0, count2 = 0, count3 = 0, count4 = 0 ;
			int totalpoints = 0, redpoints=0, yellowpoints=0, greenpoints=0, bluepoints=0;
			for (int i=0; i<11 ;i++)
			{
				if (gameBoard[0][i]== "X")
						count1=count1+1;
			}
			
			switch (count1) {
			case 0: redpoints=0;
			break;
			case 1: redpoints=1;
			break;
			case 2: redpoints=3;
			break;
			case 3: redpoints=6;
			break;
			case 4: redpoints=10;
			break;
			case 5: redpoints=15;
			break;
			case 6: redpoints=21;
			break;
			case 7: redpoints=28;
			break;
			case 8: redpoints=36;
			break;
			case 9: redpoints=45;
			break;
			case 10: redpoints=55;
			break;
			case 11: redpoints=66;
			break;
			case 12: redpoints=78;
			break;
			}
			
			for (int i=0; i<11 ;i++)
			{
				if (gameBoard[1][i]== "X")
						count2=count2+1;
			}
			
			switch (count2) {
			case 0: yellowpoints=0;
			break;
			case 1: yellowpoints=1;
			break;
			case 2: yellowpoints=3;
			break;
			case 3: yellowpoints=6;
			break;
			case 4: yellowpoints=10;
			break;
			case 5: yellowpoints=15;
			break;
			case 6: yellowpoints=21;
			break;
			case 7: yellowpoints=28;
			break;
			case 8: yellowpoints=36;
			break;
			case 9: yellowpoints=45;
			break;
			case 10: yellowpoints=55;
			break;
			case 11: yellowpoints=66;
			break;
			case 12: yellowpoints=78;
			break;
			}
			
			for (int i=0; i<11 ;i++)
			{
				if (gameBoard[2][i]== "X")
						count3=count3+1;
			}
			
			
			switch (count3) {
			case 0: greenpoints=0;
			break;
			case 1: greenpoints=1;
			break;
			case 2: greenpoints=3;
			break;
			case 3: greenpoints=6;
			break;
			case 4: greenpoints=10;
			break;
			case 5: greenpoints=15;
			break;
			case 6: greenpoints=21;
			break;
			case 7: greenpoints=28;
			break;
			case 8: greenpoints=36;
			break;
			case 9: greenpoints=45;
			break;
			case 10: greenpoints=55;
			break;
			case 11: greenpoints=66;
			break;
			case 12: greenpoints=78;
			break;
			}
			
			for (int i=0; i<11 ;i++)
			{
				if (gameBoard[3][i]== "X")
						count4=count4+1;
			}
			
			switch (count4) {
			case 0: bluepoints=0;
			break;
			case 1: bluepoints=1;
			break;
			case 2: bluepoints=3;
			break;
			case 3: bluepoints=6;
			break;
			case 4: bluepoints=10;
			break;
			case 5: bluepoints=15;
			break;
			case 6: bluepoints=21;
			break;
			case 7: bluepoints=28;
			break;
			case 8: bluepoints=36;
			break;
			case 9: bluepoints=45;
			break;
			case 10: bluepoints=55;
			break;
			case 11: bluepoints=66;
			break;
			case 12: bluepoints=78;
			break;
			}
		
		
		totalpoints = redpoints + yellowpoints + greenpoints + bluepoints - negativePoints; 
		
		return totalpoints;
		
		}
	
}